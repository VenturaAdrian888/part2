<ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="/">Rooms</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/customers">Customer</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href=<?php echo e("/logout"); ?>>Logout</a>
      </li>
    </ul><?php /**PATH D:\loob\part2\resources\views/components/items.blade.php ENDPATH**/ ?>