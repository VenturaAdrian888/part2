<ul class="navbar-nav">
      <!-- <li class="nav-item">
        <b><a class="nav-link" href="/rooms">Rooms</a></b>
      </li> -->
      <li class="nav-item">
      <b><a class="nav-link" href="/">Customer</a></b>
      </li>
      <li class="nav-item">
      <b><a class="nav-link" href="/add">Add Customer</a></b>
      </li>
      <li class="nav-item">
      <b><a  class="nav-link" href={{"/logout"}}>Logout</a></b>
      </li>
    </ul>