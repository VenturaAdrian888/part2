<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>

<table class="table table-dark table-striped" >
  <thead>
    <tr  style="background: linear-gradient(to bottom, #28313B 0%, #485461 100%); text-align:center; color:white" font-family:Sans-serif">
            <th scope="col" >RoomID</th>
            <th scope="col">Room Description</th>
            <th scope="col">Room Capacity</th>
            <th scope="col">Date From:</th>
            <th scope="col">Date To:</th>
    </tr>
  </thead>
  <tbody>
 
  <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr style="background: linear-gradient(to bottom, #D7E1EC 0%, #FFFFFF 100%); text-align:center;">
      <td> <?php echo e($room->id); ?> </td>
      <td> <?php echo e($room->roomDescription); ?> </td>
      <td> <?php echo e($room->roomCapacity); ?> </td>
      <td> <?php echo e($room->dateFrom); ?> </td>
      <td> <?php echo e($room->dateTo); ?> </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    
</body>
</html><?php /**PATH D:\part2\resources\views/room/index.blade.php ENDPATH**/ ?>