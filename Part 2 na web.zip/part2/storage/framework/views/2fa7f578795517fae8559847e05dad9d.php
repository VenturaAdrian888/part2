<ul class="navbar-nav">
      <li class="nav-item">
        <b><a class="nav-link" href="/rooms">Rooms</a></b>
      </li>
      <li class="nav-item">
      <b><a class="nav-link" href="/">Customer</a></b>
      </li>
      <li class="nav-item">
      <b><a  class="nav-link" href=<?php echo e("/logout"); ?>>Logout</a></b>
      </li>
    </ul><?php /**PATH D:\part2\resources\views/components/items.blade.php ENDPATH**/ ?>